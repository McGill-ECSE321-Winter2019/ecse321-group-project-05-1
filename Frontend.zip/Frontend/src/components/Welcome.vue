<template>
<div id= "Welcome">
<h1>Welcome to the Cooperator</h1>
<h3>Are you a new student?</h3>
<button type="Button">Yes I am!</button>

<button type="No">No not really!</button>
</div>
</template>

<style>
</style>
<script>
</script>
