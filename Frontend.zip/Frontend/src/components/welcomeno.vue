<template>
<div id="Welcomeno">
<h2> 
Welcome to the cooperator!
</h2>
<table align=center>
<tr>
<td>Full Name</td>
</td>
<td>
<input type="text" placeholder="First Name">
</td>
</tr>
<tr>
<td>Email ID</td>
<td>
<input type="text" placeholder="McGill Email">
</td>
</tr>
<tr>
<td>McGill ID</td>
<td>
<input type="number" placeholder="McGill ID Number">
</td>
</tr>
<tr>
<td></td>
<td>
<button align=center>Add me!</button>
</td>
</tr>
</table>
</div>
</template>
<style>
</style>
<script>
</script>

