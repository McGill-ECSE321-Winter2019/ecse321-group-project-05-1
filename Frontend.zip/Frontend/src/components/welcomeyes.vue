<template>
<div id="welcomeyes">
<h2>Student ID?</h2>
<table align="center">
<tr>
<td>
<input type= "text" v-model="studentid"   placeholder="Student ID">
<button>Go to my Dashboard</button>
</td>
</tr>
</table>
</div>
</template>
<style>
#welcomeyes {
font-family: 'Avenir', Helvetica, Arial, sans-serif;
  color: #2c3e50;
}
</style>
</script>
