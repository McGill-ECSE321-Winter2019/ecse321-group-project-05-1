<template>

<div id="dashboard">
<table id="head" align="left" style="width: 100%">
<tr>
<td>
<h1 align=left id=dashboard1>Welcome Tushar</h1>
</td>
<td><h1 align=right id=dashboard1>Student ID: 260721680</h1></td></tr>
</table>
<ul>
  <li><h5><a class="active" href="#Dashboard">Dashboard</a></h5></li>
  <li><h5><a href="#initialreport">Initial Report</a></h5></li>
  <li><h5><a href="#contact">Technical Report</a></h5></li>
  <li><h5><a href="#evaluation">Evaluation From</a></h5></li>
    <li><h5><a href="#settings">Settings</a></h5></li>
</ul>
<table id=body>
<tr>
<tr id=progress>
<H3>You're progress is 75%</h3>
<progress max="100" value="75"> </progress>
<tr>
</td>
</tr>
</table>
</div>
</template>

<style>

#head{background-color:#696969}
#dashboard1{color:white}
#dashborard{padding-left:20px}
h2{color:white}
h2{padding-right:20px}

#progress{
	margin-top:200px;
}

ul {
  list-style-type: none;
  padding: 0;
  width: 25%;
  background-color: grey;
  position: fixed;
  height: 100%;
  overflow: auto;
  border-color: white;
  margin-top:58px;
}

li a {
  display: block;
  color: white;
  padding: 20px 16px;
  text-decoration: none;
 border-color: white;
  
}
li a.active {
  background-color: #4CAF50;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
border-color: white;
}
#box1{
  margin-top:200%;
  color:grey;
 border: black;
  }
#body{
  margin-top:30px;
   width: 125%;
}
</style>

<script>
</script>
