import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Welcome from '@/components/Welcome'
import welcomeyes from '@/components/welcomeyes'
import welcomeno from '@/components/welcomeno'
import addcoop from '@/components/addcoop'
import dashboard from '@/components/dashboard'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    },
{
      path: '/welcome',
      name: 'Welcome',
      component: Welcome
    },
{
      path: '/welcomeyes',
      name: 'welcomeyes',
      component: welcomeyes
    },
{
      path: '/welcomeno',
      name: 'welcomeno',
      component: welcomeno
   },
{
     path: '/addcoop',
     name: 'addcoop',
     component: addcoop
},
{
     path: '/dashboard',
     name: 'dashboard',
     component: dashboard
}	
  ]
})

