
import axios from 'axios'
var config = require('../../config')

var frontendUrl = 'http://' + config.dev.host + ':' + config.dev.port
var backendUrl = 'http://' + config.dev.backendHost + ':' + config.dev.backendPort

var AXIOS = axios.create({
  baseURL: backendUrl,
  headers: { 'Access-Control-Allow-Origin': frontendUrl }
})

function studentDto (student, email,id) {
  this.student = student
  this.email= email
  this.id= id
}


export default {
  name: 'welcomenoo',
  data () {
    return {
      students: [],
      newStudents: '',
    }
  },

created: function(){
  const p1=new studentDto('TUSHAR','tushar.agarwal@mail.mcgill.ca', '260721680')
  this.students=[p1]
},

methods: {
  createstudents: function (Student, Email,Id) {
    AXIOS.post(`/students/`+'?mcgillID=' + Id + 'name=' + Student + 'email=' + Email , {}, {})
    .then(response => {
      // JSON responses are automatically parsed.
      this.students.push(response.data)})
    // Create a new person and add it to the list of people
    //var p = new studentDto(Student,Email,Id)
    //this.students.push(p)
    // Reset the name field for new people
    //this.newStudents = ''
  }
}
}